export default {
  platform: 'node'
};