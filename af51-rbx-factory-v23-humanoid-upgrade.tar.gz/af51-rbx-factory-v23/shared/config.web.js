export default {
  platform: 'web'
};